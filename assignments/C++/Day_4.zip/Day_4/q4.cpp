#include <iostream>

using namespace std;

int main()
{
    int num1, num2;
    do{
        cout << "enter 2 numbers to find prime numbers between them : ";
        cin >> num1 >> num2;
    }while(num1<0 || num2<0);
    if (num1>num2){
        int temp=num1;
        num1=num2;
        num2=temp;
    }
    cout << "prime numbers between " << num1 << " and " << num2 << " are : ";
    for(int i=num1; i<=num2; i++){
        int count=0;
        for(int j=1; j<=i; j++){
            if(i%j==0){
                count++;
            }
        }
        if(count<3){
            cout << i << " ";
        }
    }
    cout << endl;
}
#include <iostream>

using namespace std;

int main()
{
    int num1, num2, sum=0;
    do{
        cout << "enter 2 numbers to find sum of numbers between them : ";
        cin >> num1 >> num2;
    }while(num1<0 || num2<0);
    if(num1>num2){
        int temp=num1;
        num1=num2;
        num2=temp;
    }
    for (int i=num1; i<=num2; i++){
        sum = sum+i;
    }
    cout << "sum of numbers between " << num1 << " and " << num2 << " is " << sum << endl;
    return 0;
}
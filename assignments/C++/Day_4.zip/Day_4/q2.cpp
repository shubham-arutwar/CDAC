#include <iostream>
using namespace std;

int main() {

  int num, reversed_number = 0, remainder;
  do{
    cout << "enter a positive integer : ";
    cin >> num;
  }while(num<0);
  for(num; num != 0; num /= 10){
    remainder = num % 10;
    reversed_number = reversed_number * 10 + remainder;
  }
  cout << "Reversed Number = " << reversed_number << endl;
}
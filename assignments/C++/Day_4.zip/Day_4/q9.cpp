#include <iostream>
using namespace std;

int main() {
    int num;
    cout<<"Enter a number : ";
    do{
        cin>>num;
    }while(num<0);
    int reverse=0;
    int rem, temp;
    temp = num;
    for(num; num!=0; num/=10){
        rem=num%10;
        reverse=reverse*10+rem;
    }
    if(temp==reverse) {
        cout<<"Number is palindrome" << endl;
    }
    else {
        cout<<"Number is not palindrome" << endl;
    }
}
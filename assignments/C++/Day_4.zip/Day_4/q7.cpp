#include <iostream>
using namespace std;

int main() {
    int num;
    do{
        cout<<"Enter a number : ";
        cin>>num;
    }while(num<0);
    int ans;
    int sum=0;
    if(num<0){
        num=num*(-1);
    }
    for(num; num!=0; num=num/10){
        ans=num%10;
        sum=sum+ans;
    }
    cout<<"Sum of all digits in a number is : " << sum << endl;
}
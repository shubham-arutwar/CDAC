#include <iostream>
using namespace std;

int main() {
    int num;
    cout<<"Enter a number : ";
    do{
        cin>>num;
    }while(num<0);
    int ans;
    int product=1;

    for(num; num!=0; num/=10){
        ans=num%10;
        product=product*ans;
    }
    
    cout<<"product of all digits in a number is :"<<product << endl;
}
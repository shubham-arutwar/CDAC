/*5. Given an array of n integers, find the given element. Return true if element is present in the array else return false.
bool search(int nums[], int n, int element);*/

#include<iostream>
using namespace std;

bool search(int arr[], int num, int array_size){
    bool sw=0;
    for(int i=0; i<array_size; i++){
        arr[i]==num ? sw=1 : sw=0;
        if(sw==1){
            break;
        }
    }
    return sw;
}

int main(){
    int array_size, num;
    int *arr = new int[array_size];
    cout << "Enter number of input integers : ";
    cin >> array_size;
    for(int i=0; i<array_size; i++){
        cout << "Enter element number " << i+1 << " : ";
        cin >> arr[i];
    }
    cout << "Enter a number to find check if it is in array : ";
    cin >> num;
    0==search(arr, num, array_size) ? cout << "Entered number is not present in array" : cout << "Entered number is present in array";
    cout << endl;
}
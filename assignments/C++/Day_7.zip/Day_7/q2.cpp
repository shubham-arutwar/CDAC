/*2. Given an array of n integers, find the smallest element and return if from function.
int findMin(int nums[], int n);*/

#include<iostream>
using namespace std;

int findMin(int arr[], int array_size){
    int min;
    for(int i=0; i<array_size; i++){
        if(i==0){
            min=arr[i];
        }
        else{
            min>arr[i] ? min=arr[i] : min;
        }
    }
    return min;
}

int main(){
    int array_size;
    int *arr = new int[array_size];
    cout << "Enter number of input integers : ";
    cin >> array_size;
    for(int i=0; i<array_size; i++){
        cout << "Enter element number " << i+1 << " : ";
        cin >> arr[i];
    }
    cout << "Smallest number out of entered number is : " << findMin(arr,array_size) << endl;
}
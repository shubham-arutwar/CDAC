/*1. Given an array of n integers, find the largest element and return if from function.
int findMax(int nums[], int n);*/

#include<iostream>
using namespace std;

int findMax(int arr[], int array_size){
    int max;
    for(int i=0; i<array_size; i++){
        if(i==0){
            max=arr[i];
        }
        else{
            max<arr[i] ? max=arr[i] : max;
        }
    }
    return max;
}

int main(){
    int array_size;
    int *arr = new int[array_size];
    cout << "Enter number of input integers : ";
    cin >> array_size;
    for(int i=0; i<array_size; i++){
        cout << "Enter element number " << i+1 << " : ";
        cin >> arr[i];
    }
    cout << "Largest number out of entered number is : " << findMax(arr,array_size) << endl;
}
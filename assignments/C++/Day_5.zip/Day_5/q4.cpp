#include<iostream>
using namespace std;

void prime(int num1,int num2)
{
    for(int i=num1; i<=num2; i++){
        int count=0;
        for(int j=1; j<=i; j++){
            if(i%j==0){
                count++;
            }
        }
        if(count<3){
            cout << i << " ";
        }
    }
    cout << endl;
}

int main()
{
    int n1,n2;
    cout<<"Enter the 1st number : ";
    cin>>n1;
    cout<<"Enter the 2nd number : ";
    cin>>n2;
    cout<<"Prime numbers between "<<n1<<" and "<<n2<<" are : ";
    prime(n1,n2);
    
}

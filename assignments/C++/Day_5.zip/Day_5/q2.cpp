#include<iostream>
using namespace std;

void isprime(int a){
    bool isprime=0;
    for(int j=2; j<a; j++){
        if(a%j==0){
            isprime=1;
            break;
        }
    }
    if(isprime==0){
        cout << "Number is prime number";
    }
    else if(isprime==1){
        cout << "Number is not prime number";
    }
    cout << endl;
}

int main(){
    int num;
    cout<<"Enter a number : ";
    cin>>num;
    isprime(num);
}
#include<iostream>
using namespace std;

int reverse(int num)
    {                       
        int tmp=0;
    while(num>0)
    {
        int rem=num%10;
        tmp=rem+(tmp*10);
        num=num/10;
    }
return tmp;
}
int main()
{
    int num;
    do{
        cout<<"Enter the number : ";
        cin>>num;
    }while(num<0);
    cout<< "reversed number is : "<< reverse(num) << endl;
}
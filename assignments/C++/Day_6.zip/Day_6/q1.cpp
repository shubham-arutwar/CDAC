#include <iostream>
using namespace std;

void swap(int& a, int& b) {
    int temp = a;
    a = b;
    b = temp;
}


void swap(double& a, double& b) {
    double temp = a;
    a = b;
    b = temp;
}

void swap(char& a, char& b) {
    char temp = a;
    a = b;
    b = temp;
}

int main() {

    int x = 5, y = 10;
    double a = 3.14, b = 6.28;
    char c1 = 'A', c2 = 'B';

    cout << "Before swapping:" << endl;
    cout << "x = " << x << ", y = " << y << endl;
    cout << "a = " << a << ", b = " << b << endl;
    cout << "c1 = " << c1 << ", c2 = " << c2 << endl;

    swap(x, y);
    swap(a, b);
    swap(c1, c2);

    cout << "After swapping:" << endl;
    cout << "x = " << x << ", y = " << y << endl;
    cout << "a = " << a << ", b = " << b << endl;
    cout << "c1 = " << c1 << ", c2 = " << c2 << endl;

    return 0;
}
